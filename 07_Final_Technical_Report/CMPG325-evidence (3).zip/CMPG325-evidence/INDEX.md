# CMPG 325 evidence index (project CMPG325-2026-044)

| File | Shows | Report section |
|---|---|---|
| 00 | Topology after cabling Router1, Router2, ISP1, ISP2 | 3 |
| 01 | Office-PC1: ping and tracert to the Internet test addresses (IPv4 and IPv6) | 6, 9 |
| 02-07 | CORE-SW: IPv4 and IPv6 interfaces, routing tables, floating routes | 4, 5, 6 |
| 08-09 | CCTV ACLs: configuration and listing | 7 |
| 10-14 | Camera addresses and gateways | 4.3 |
| 15-16 | Company-Server and Office-PC1 ipconfig | 4.3 |
| 17-20 | Company-Server pings to cameras (IPv4 and IPv6) succeed | 7.2 |
| 21-22 | Office-PC1 pings to camera blocked (IPv4 and IPv6) | 7.2 |
| 23 | Office-PC1 pings to server succeed (IPv4 and IPv6) | 7.2 |
| 24 | ACL match counts | 7.2 |
| 25-27 | Router1 interfaces, routes, NAT, ACL 1 | 5.2 |
| 28-29 | Router2 config and ping to Internet test addresses | 5.2, 8 |
| 30-31 | Failover: core route before, shutdown of Gi1/0/5 | 8.2 |
| 32 | Failover: tracert before (photo, taken via Router1) | 8.2 |
| 33 | Failover: tracert after (via Router2, IPv4 and IPv6) | 8.2 |
| 34-36 | Restore, failback route, failback tracert | 8.2 |
| 39-40 | Failover: CORE-SW IPv4 and IPv6 routes with the AD 254 backup active (via 10.24.254.6 and 2001:DB8:24:F2::2) | 8.2 |
| 41 | Failover: Router2 NAT translations (10.24.10.10 translated to 203.0.113.5) | 8.2 |
| 37-38 | Reopen test of the saved .pkt | 9 |
| troubleshooting/T1-T4 | Camera gateway problem | 10 |

## Not captured yet (take these if time allows)
1. Clean full-size topology (File > Export or a screenshot with device labels readable).
2. (done: files 39-41)
4. A clean tracert before the failover (32 is a photo).
5. ISP1 and ISP2 `show ip interface brief` (where 8.8.8.8 lives).
6. CORE-SW `show vlan brief` and `show interfaces trunk`.
